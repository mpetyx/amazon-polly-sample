**To create a pipeline**

This example creates a pipeline::

   aws datapipeline create-pipeline --name my-pipeline --unique-id my-pipeline-token
   
The following is example output::

  {
      "pipelineId": "df-00627471SOVYZEXAMPLE"
  }
